#!bin/bash

update() {
    clear
    echo "************************************"
    echo "Orb362 TEST SCRIPT MAIN"
    echo "------------------------------------"
    echo "$STATUSFEED"
    echo "************************************"
    case $uinput in
	#0 ) echo "Select user script:"
	    
	* ) echo "Select test case:"
	    echo "-1. Record a script"
	    echo "0. User-written or recorded script"
	    echo "1. All included test cases"
	    echo "2. 'Must stay inside'"
	    echo -n ">> ";;
    esac
}

mainSelect() {

    #echo "Select test case:"
    #echo "0. User-made script"
    #echo "1. All included test cases"
    #echo "2. 'Must stay inside'"
    #echo -n ">> "

    read uinput
    #echo $uinput

    case $uinput in
	-1 ) runRecord;;
	0 ) runUserWritten;;
	1 ) echo "1";;
	2 ) #bash ./testScripts/test2.sh
	    #titleBar
	    #mainSelect;;
	    runTestCase;;
	* ) STATUSFEED="Invalid option."
	    update
	    mainSelect;;
    esac
}

runTestCase() {
    STATUSFEED="Running test case $uinput..."
    update
    RESULTS=`bash ./testScripts/test$uinput.sh`
    #if [$RESULTS -eq ""] ; then
	STATUSFEED="Successful run.  Output saved as $RESULTS.txt"
    #else
	#STATUSFEED="Error $RESULTS occurred in run.  Check output $DATEVAL.txt"
    #fi
    update
    mainSelect
}

runUserWritten() {
    STATUSFEED="Enter name of custom command text file (ex: customTest1)."
    update
    read uinput
    STATUSFEED="Enter debug mode value (no entry enables all debug methods)." #must catch for invalid values
    update
    read uinput2
    STATUSFEED="Enter 2 for test case and friendlier command output, 1 for direct-to-command-file text only, 0 for test case output only." #must catch for invalid values
    update
    read uinput3
    RESULTS=$(ls -1 ./testScripts/custom | grep -c $uinput)
    case $RESULTS in
	0 ) STATUSFEED="Custom test case $uinput not found."
	    update
	    #echo "$RESULTS"
	    mainSelect;;
	* ) STATUSFEED="Running custom test case $uinput..."
	    update
	    RESULTS=`bash ./testScripts/customTest.sh $uinput $uinput2 $uinput3`
	    STATUSFEED="Successful run. Output saved as $RESULTS.txt."
	    update
	    mainSelect;;
    esac
}

runRecord() {
    STATUSFEED="Enter what you would like to call recorded file."
    update
    read uinput
    STATUSFEED="Recording input..."
    update
    RESULTS=`bash ./testScripts/record.sh $uinput`
    STATUSFEED="Successful run.  Recording saved as $RESULTS.txt in custom folder"
    update
    mainSelect;
}


STATUSFEED=""
RESULTS=""
update
mainSelect
