#!bin/bash

###TESTING TEMPLATE###
#open gnome terminal and run Orb362.jar
gnome-terminal
xdotool sleep 0.5
xdotool type "cd .."
xdotool key Return
TERMID=`xdotool getactivewindow`
DATEVAL=`date +%m-%d-%y_%H:%M:%S_TESTRUN`
xdotool type "java -jar ./Orb362.jar 1 0 0 >> ./test/testOutputs/$DATEVAL.txt"
xdotool key Return

#select orb window
xdotool sleep 0.5
ORBID=`xdotool search --name "Orbit" | sort | head -1`
xdotool windowactivate --sync $ORBID
xdotool sleep 0.5
###TESTING TEMPLATE###


#perform actions in orb
xdotool keydown space
xdotool keyup space
xdotool sleep 0.4
xdotool keydown space
xdotool sleep 3.0
xdotool keyup space
xdotool sleep 1.5

#exit and state saved file
xdotool windowclose $ORBID
xdotool windowclose $TERMID

#clear
#echo "************************************"
#echo "Orb362 TEST SCRIPT MAIN"
#echo "------------------------------------"
#echo "Test case successful! Output saved as $DATEVAL.txt in /testOutputs/"
#echo "************************************"
#echo "Test case successful! Output saved as $DATEVAL.txt in /testOutputs/"

echo "$DATEVAL"
exit 0
