#!bin/bash

###TESTING TEMPLATE###
#open gnome terminal and run Orb362.jar

if test "$2" = ""
then
    DEBUGVAL="31"
else
    DEBUGVAL="$2"
fi

gnome-terminal
xdotool sleep 0.5
xdotool type "cd .."
xdotool key Return
TERMID=`xdotool getactivewindow`
#DATEVAL=`date +%m-%d-%y_%H:%M:%S_TESTRUN`
DATEVAL=`date +%H:%M_TEST`
xdotool type "java -jar ./Orb362.jar $DEBUGVAL 0 $3 >> ./test/testOutputs/$1_$DATEVAL.txt"
xdotool key Return

#select orb window
xdotool sleep 0.5
ORBID=`xdotool search --name "Orbit" | sort | head -1`
xdotool windowactivate --sync $ORBID
xdotool sleep 1.0
###TESTING TEMPLATE###

#perform actions in orb
CUSTOMFILE="./testScripts/custom/$1.txt"
while IFS= read -r var
do
    #echo "$var"
    xdotool $var
done < "$CUSTOMFILE"
xdotool sleep 1


#exit and state saved file
xdotool windowclose $ORBID
xdotool windowclose $TERMID

#clear
#echo "************************************"
#echo "Orb362 TEST SCRIPT MAIN"
#echo "------------------------------------"
#echo "Test case successful! Output saved as $DATEVAL.txt in /testOutputs/"
#echo "************************************"
#echo "Test case successful! Output saved as $DATEVAL.txt in /testOutputs/"

echo "$1_$DATEVAL"
exit 0
