/*
    This file is part of Orb.

    Orb is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    Orb is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Orb.  If not, see <http://www.gnu.org/licenses/>. 
    
    This software was developed by members of Project:Possibility, a software 
    collaboration for the disabled.
    
    For more information, visit http://projectpossibility.org
*/


import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Polygon;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.IOException;
import java.util.ArrayList;

import javax.swing.Timer;

//EDIT
import java.awt.image.ImageObserver;
//EDIT END

/**Main game class
 * 
 * @author James Myoung
 *
 */
public class Orbit extends Object {
	static Player player = new Player();
	static Boolean key1 = false;
	static Boolean key2 = false;
	static Timer tickTimer;
	//static Timer winTimer;
	static GameWindow gameWindow = new GameWindow();
	static MapLoader mapLoader = new MapLoader(gameWindow);
	static ArrayList maps = new ArrayList();
	static CollisionDetection2 collisionDetection = new CollisionDetection2(player);
	static ArrayList<Star> stars = new ArrayList<Star>();
	//static Sound crashSound = new Sound();
	//static Sound thrustSound = new Sound();
	//static Sound collectSound = new Sound();
	static Polygon level1 = new Polygon();
	static int currentLevel = 0;
	static HUD hud;
	static KeyListener listener;
        
        //EDIT
        static Boolean debugMode = false;
        static int debugCount;
        static int [] debugOps;
        
        static String keyText;
        static int keyCode;
        
        static int totalStarsCollected = 0;
        static int totalStarsAvailable;
        
        static long  tick = 0;
        static long tickBeginSpace = 0;
        static long tickEndSpace = 0;
        static long tickBeginC = 0;
        static long tickEndC = 0;
        static Boolean tickScriptHelp = false;
        static Boolean recording = false;
        
        static Timer menuTimer;
        static Boolean menu = true;
        
        //static ArrayList <ImageObserver> imageObservers = new ArrayList<ImageObserver>();
        //EDIT

/**
 * 
 * @param args
 */
	public static void main(String[] args) {
		//Initialization
		try {
			maps.add(mapLoader.readFile("./media/map.txt"));
			maps.add(mapLoader.readFile("./media/map2.txt"));
			maps.add(mapLoader.readFile("./media/map3.txt"));
			//maps.add(mapLoader.readFile("src/easy_level_1.txt"));
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		
		stars = mapLoader.generateStars("./media/map.txt");
                
                //EDIT
                totalStarsAvailable = stars.size();
                //EDIT END
                
		player.changeHealth(100);
                
                //EDIT
                try {
                    if(args.length > 1) {  //make switch case
                        if(Integer.parseInt(args[1]) == 2) {
                            player.setCharacter(1);
                            player.setRadius(15);
                        }
                        if(Integer.parseInt(args[2]) == 2) {
                            tickScriptHelp = true;
                            System.out.printf("Tick script help active.\n");
                        }
                        else if(Integer.parseInt(args[2]) == 1) {
                            recording = true;
                        }
                    }
                }catch(NumberFormatException e) {
                    //DO NOTHING AND CONTINUE
                }
                //EDIT END
                
		hud = new HUD();
		
		gameWindow.setPlayer(player);
		gameWindow.setStars(stars);
                
                //EDIT
                //gameWindow.setImageObservers(imageObservers);
                //EDIT END
                
		gameWindow.setPolygon(mapLoader.getPolygon(currentLevel));
		

		//Input
		
		listener = new KeyListener() { //WHEN ADDING THE INPUT-TO-TEXT FOR SCRIPTING THERE MUST BE MORE COMPLEX CASES, AS RELEASING OR PRESSING c
                                               //WHILE space IS PRESSED WILL COMPLICATE THE OUTPUTS.  MUST SOMEHOW COME UP WITH MORE COMPLEX CONDITIONAL
                                               //PRINTS.  CURRENTLY ONLY HAVE IT "CORRECTLY" FORMATTED FOR spaceS, AS IT TECHNICALLY SHOULD BE TO SATISFY
                                               //THE WHOLE ORIGINAL POINT OF THE PROJECT
			public void keyPressed(KeyEvent e) {
                                //EDIT
                                keyCode = e.getKeyCode();
                                keyText = KeyEvent.getKeyText(keyCode);
                                //EDIT END
				switch (e.getKeyCode()) {
				case KeyEvent.VK_SPACE:
                                    //EDIT
                                    if(tickScriptHelp == true && key1 == false) {
                                        //f(args[2] != "1") {
                                        System.out.printf("%f: %s pressed.\n",(double)tick*.034,keyText);
                                    }
                                    else if(recording == true && key1 == false) {
                                        System.out.printf("sleep %f\n",(double)(tick-tickEndSpace)*.034);
                                        tickBeginSpace = tick;
                                        System.out.printf("keydown space\n");
                                    }
                                    //EDIT END
                                    key1 = true;
                                    break;
				case KeyEvent.VK_C: 
                                    //EDIT
                                    if(tickScriptHelp == true && key2 == false) {
                                        //if(args[2] != "1") {
                                        System.out.printf("%f: %s pressed.\n",(double)tick*.034,keyText);
                                    }
                                    else if(recording == true && key2 == false) {
                                        tickBeginC = tick;
                                        System.out.printf("keydown c\n");
                                    }
                                    //EDIT END
                                    key2 = true;
                                    break;
				//case KeyEvent.VK_Z: currentLevel = 2; break; //HACK for testing. Charlene
				}
				//System.out.println("Key Down");
				try
				{
                                        /* DISABLED SOUND */
					//thrustSound.playAudio("./media/406ship1player2engine.wav");
				}
				catch(Exception e2)
				{           
					System.out.println(e2);
				}
			}

			/** Handles a key release event.
			 * 
			 */
			public void keyReleased(KeyEvent e) {
                                //EDIT
                                keyCode = e.getKeyCode();
                                keyText = KeyEvent.getKeyText(keyCode);
                                //EDIT END
				switch (e.getKeyCode()) {
				case KeyEvent.VK_SPACE:
                                    //EDIT
                                    if(tickScriptHelp == true && key1 == true) {
                                        //if(args[2] != "1") {
                                        System.out.printf("%f: %s released.\n",(double)tick*.034,keyText);
                                    }
                                    else if(recording == true && key1 == true){
                                        tickEndSpace = tick;
                                        System.out.printf("sleep %f\n",(double)(tickEndSpace-tickBeginSpace)*.034);
                                        System.out.printf("keyup space\n");
                                    }
                                    //EDIT END
                                    key1 = false;
                                    break;
				case KeyEvent.VK_C: 
                                    //EDIT
                                    if(tickScriptHelp == true && key2 == true) {
                                        //if(args[2] != "1") {
                                        System.out.printf("%f: %s released.\n",(double)tick*.034,keyText);
                                    }
                                    else if(recording == true && key2 == true) {
                                        tickEndC = tick;
                                        System.out.printf("sleep %f\n", (double)(tickEndC-tickBeginC)*.034);
                                        System.out.printf("keyup c\n");
                                    }
                                    //EDIT END
                                    key2 = false;
                                    break; //modifier that slows the player
				//case KeyEvent.VK_Z: currentLevel = 2; break; //HACK for testing. Charlene
				}
				//System.out.println("Key Up");
                                
                                /* DISABLED SOUND */
				//thrustSound.stopAudio();
			}

			/** Handles a key hit event.
			 * 
			 */
			public void keyTyped(KeyEvent e) {}


		};
                //EDIT; ISSUE WITH THE debugVal CONVERTER WHEN IN INPUT-TO-TEXT MODE: debugVal <= 0 THROWS EXCEPTION; MAKE ELSE IF 
                //args[0] = 0 TO BYPASS CATCH?
                try{
                    if(args.length < 3 || Integer.parseInt(args[2]) != 1) {
                        System.out.printf("*****\n");
                        for(int i = 0; i < args.length; i++) {
                            System.out.printf("args[%d] = %s\n",i,args[i]);
                        }
                        System.out.printf("*****\n");
                    }
                }catch(ArrayIndexOutOfBoundsException e) {
                    System.out.printf("No main() arguments, running normally.\n");
                }
                
                if(args.length != 0) {
                    try {
                        int debugVal;
                        debugVal = Integer.parseInt(args[0]);
                        if(debugVal > 0) { //WILL CREATE BAD OUTPUT FOR INPUT-TO-TEXT IF YOU UNCOMMENT THE CATCH AND RUN WITH args[0]<=0
                            debugMode = true;
                            String debugValBin = Integer.toBinaryString(debugVal);
                            debugCount = 0;
                            for(int i = 0; i < debugValBin.length(); i++) {
                                if(debugValBin.charAt(i) == '1') {
                                    debugCount++;
                                }
                            }
                            debugOps = new int [debugCount];
                            int index = 0;
                            //debugOps[0] = 9;
                            //System.out.printf("%d\n", debugOps[index]);
                            //System.out.printf("debugValBin: %s\n",debugValBin);
                            while(debugValBin.indexOf('1') != -1) {
                                
                                //System.out.printf("debugValBin: %s\n",debugValBin);
                                //System.out.printf("index: %d\n",index);
                                
                                debugOps[index] = (int) Math.pow(2, (debugValBin.length() - 1) - debugValBin.indexOf('1'));
                                debugValBin = debugValBin.replaceFirst("1", "0");
                                index++;
                            }
                            //TO MAKE SURE debugOps[] HAVE CORRECT VALUES
                            if(args.length < 3 || Integer.parseInt(args[2]) != 1) {
                                System.out.printf("Debug mode active.  Debug value array: [");
                                for(int i = 0; i < debugCount; i++) {
                                    if(i == debugCount - 1) {
                                        System.out.printf("%d", debugOps[i]);
                                    }
                                    else {
                                        System.out.printf("%d, ", debugOps[i]);
                                    }
                                }
                                System.out.printf("]\n");
                            }
                        }
                        else {
                            throw new NumberFormatException();
                        }
                    }
                    catch(NumberFormatException e) {
                        //System.out.printf("Incorrect debug input, not a positive integer. Running as normal.\n");
                    }
                }
                //END EDIT
                
		gameWindow.addKeyListener(listener);
		tickTimer = new javax.swing.Timer(34, new ActionListener() { //34
			public void actionPerformed(ActionEvent e) {
                                //EDIT
                                if(menu == true) {
                                    welcomeScreen(); //INSTEAD OF INFINITE WHILE LOOP THIS DOES TIMER UPDATES, MUCH MORE EFFICIENT, BUT KEYLISTENER MAY UPDATE
                                                    //BEFORE TIMER UPDATE, MISSING AN INPUT BUT STILL PRINTING THAT OUT
                                                    //MAY BE WHAT OCCURS WITH THE SCRIPT TIMING INCONSISTENCIES: SLEEP VALUES NOT MULTIPLES OF THE TICK TIME
                                }
                                else {
                                    tick();
                                    //EDIT
                                    gameWindow.run(); //MODIFIED GameWindow.run() TO WAIT TO BE CALLED, MORE EFFICIENT AND PROBABLY ELIMINATES CHOPPING ARTIFACTS
                                    //EDIT END
                                }
                                //EDIT END
			}
		});
		
                
                
		//welcomeScreen(); //ADDED TIMER WITHIN welcomeScreen() TO GATHER TICKS BEFORE WELCOME SCREEN IS EXITED
		tickTimer.start();
                
                
	}
	/**
	 * Tick is a function that is called 30 time a second. It does game updating and displaying.
	 *
	 */
	public static void tick(){
		//Update
            
                //EDIT
                tick++;
                //System.out.printf("%d\n",tick);
                //EDIT END
                
		player.update(key1, key2);
		if(player.getMainPosition().x <0 || player.getMainPosition().y < 0 || player.getMainPosition().x > 640 || player.getMainPosition().y > 480){
			player.die();
			player.changeHealth(100);
			hud.updateHealth(player.getHealth());
		}else{
			for(Object line: (ArrayList)maps.get(currentLevel)){  //for each Line object in this level's ArrayList<Line>...
				if(collisionDetection.collideWithLine((Line) line)){
					//System.out.println("Hit Wall");
					try{
                                            /* DISABLED SOUND */
                                            //crashSound.playAudio("./media/bounce.wav");
                                        }
					catch(Exception e){System.out.println(e);}
					player.changeHealth(-15);
					hud.updateHealth(player.getHealth());
					break;
				}
				else{
                                        /* DISABLED SOUND */
					//crashSound.stopAudio();
				}
			}
			//for(Object star:stars){
			for(int i = 0; i < stars.size(); i++){
				if(collisionDetection.genericCollision(new Position(((Star)stars.get(i)).getX(),((Star)stars.get(i)).getY()),10)){
					player.changeHealth(100);
					hud.updateHealth(player.getHealth());
					//System.out.println("COLLECTED A STAR!!!");
					//Update stars to display in game window
					gameWindow.setStars(stars);
					stars.remove(stars.get(i));
					//Update stars to display in game window
					gameWindow.setStars(stars);
                                        
                                        //EDIT
                                        totalStarsCollected++;
                                        
                                        //EDIT END
					//System.out.println("Star #: "+ stars.size());
					try{
                                            /* DISABLED SOUND */
                                            //collectSound.playAudio("src/bicycle_bell.wav");
                                        }
					catch(Exception e){System.out.println(e);}
					break;
				}
				else{
                                        /* DISABLED SOUND */
					//collectSound.stopAudio();  
				}
			}
			//System.out.println("Health: " + player.getHealth());
			if(player.getHealth() <= 0){
				player.die();
				hud.restart();
			}
			if(stars.size()  == 0){
				player.changeHealth(100);
				hud.updateHealth(player.getHealth());
				//System.out.println("Level Passed!");
				if(currentLevel == 0){
					currentLevel++;
					stars = mapLoader.generateStars("./media/map2.txt");
					//Update stars to be displayed in game window
					gameWindow.setStars(stars);
                                        
                                        //EDIT
                                        totalStarsAvailable = totalStarsAvailable + stars.size();
                                        //EDIT END
                                        
					player.setMainPosition(100, 150);
				}
				else if(currentLevel == 1){
					currentLevel++;
					stars = mapLoader.generateStars("./media/map3.txt");
					//Update stars to be displayed in game window
					gameWindow.setStars(stars);
                                        
                                        //EDIT
                                        totalStarsAvailable = totalStarsAvailable + stars.size();
                                        //EDIT END
                                        
					player.setMainPosition(100, 150);
				} 
				else if(currentLevel == 2){
					winScreen();
				}
				else {
					//System.out.println("Level Passed!" + currentLevel);
				}
			}
		}
		//Set info for Display in Game Window
		
		gameWindow.setPlayer(player);
		gameWindow.setStars(stars);
		gameWindow.setPolygon(mapLoader.getPolygon(currentLevel));
                
                //EDIT
                
                /*if(tickScriptHelp == true) {
                    tickScript();
                }*/
                
                if(debugMode == true) {
                    for(int i = 0; i < debugCount; i++) {
                        switch(debugOps[i]) {
                            case 1:
                                collisionDetection.outsideDebug(mapLoader, currentLevel);
                                break;
                            case 2:
                                uiDebug();
                                break;
                            case 4:
                                player.healthDebug();
                                break;
                            case 8:
                                starsDebug();
                                break;
                            case 16:
                                //collisionDetection.starCollideDebug(stars); //ISSUE WITH METHOD
                                //break;
                        }
                    }
                }
                
                
                //END EDIT
		
		//gameWindow.clear();

		/*		gameWindow.getGraphics().fillPolygon(mapLoader.getPolygon(currentLevel));

		gameWindow.draw(player);


		for(Star star:stars){
			star.drawStar();
		}
*/
	}
        
        //EDIT
        /*public static void tickScript() {
            if(key1 == true || key2 == true) {
                System.out.printf("%d: %s pressed\n",tick,keyText);
            }
        }*/
        
        public static void uiDebug() {
            if ((key1 == true || key2 == true) && keyCode != KeyEvent.VK_SPACE && keyCode != KeyEvent.VK_C) { //
                System.out.printf("BUG: False key input (program reacting to key other than 'SPACE' or 'C'): %s, %d\n",keyText,keyCode);
            }
        }
        
        public static void starsDebug() {
            if(totalStarsCollected >= totalStarsAvailable && currentLevel != -1) {
                System.out.printf("BUG: totalStarsCollected >= totalStarsAvailable and without level progression: %d\n", totalStarsCollected);
            }
        }
        
        //EDIT END

	/** Displays the splash screen when game starts.
	 * 
	 */
	public static void welcomeScreen(){
		//display code
                
                //EDIT
            /*
		while(true){  //TOO NEEDY FOR EFFECTIVELY JUST A LISTENER; SHOULD JUST COMMENT OUT WHILE LOOP, CALL welcomeScreen() ONCE AS ALREADY DONE
                              //THEN ADD A CONDITIONAL IN tick() THAT CHECKS A BOOLEAN VAR SET TO true WHEN APP STARTS AND key1, THEN RUNS THE NESTED
                              //METHODS BELOW WHEN AND SETS VAR TO false WHEN BOTH ARE true
			if(key1){
				gameWindow.clear();
                                //EDIT; COMMENTING NEXT LINE BECAUSE IT SCREWS WITH MY THE INPUT-TO-TEXT SCRIPT
				//key1 = false; 
                                //EDIT END
                                
				//Start main game window (animation thread)
				gameWindow.animThread.start();
				break;
				
			}
			gameWindow.drawTitle();
		}*/
            
            /*menuTimer = new javax.swing.Timer(34, new ActionListener() { //34
			public void actionPerformed(ActionEvent e) {
                            if (key1 == true) {
                                gameWindow.clear();
                                gameWindow.animThread.start();
                                menuTimer.stop();
                                return;
                            }
                            tick++;
			}
            });
            
            menuTimer.start();*/
            
            gameWindow.drawTitle();
            if(key1 == true) {
                gameWindow.clear();
                gameWindow.animThread.start();
                menu = false;
                return;
            }
            tick++;
	}

	/** Displays the win screen when the player wins.
	 * 
	 */
	public static void winScreen(){
		//tickTimer.stop();
		//display code
            
                //EDIT
                currentLevel = -1;
                //EDIT END
                
		gameWindow.drawWin();
		tickTimer.stop();
		gameWindow.animThread = null;
		
		//Dispose of offscreen graphics context
		if(gameWindow.offscreenGraphics != null)
		{
			gameWindow.offscreenGraphics.dispose();
		}
		gameWindow.animThread = null;
		//while(gameWindow.animThread == null)
		//{
			gameWindow.drawWin();
			
			
		//}
		
		
		
		//System.out.println("WIN SCREEN: " + key1);
		//System.out.println("WIN SCREEN: " + KeyEvent.VK_SPACE);
	
		/*while(true){
			//System.out.println(key1);
			if(key1){
				System.out.println("GOT KEY");
				gameWindow.clear();
				key1 = false;

				currentLevel = 0;
				player.setMainPosition(100, 150);
				welcomeScreen();

				break;
			}
			
		} //for restarting*/
		
		
		
		/*
		winTimer = new javax.swing.Timer(3000, new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				gameWindow.clear();
				currentLevel = 0;
				player.setMainPosition(100, 150);
				welcomeScreen();
				//tickTimer.start();

			}
		});

		winTimer.start();
		 */
	}
        
        public static void closingDebugPrint() {
            if(recording == true) {
                System.out.printf("sleep %f\n", (double)(tick-tickEndSpace)*.034);
            }
        }

}



