#!bin/bash

###TESTING TEMPLATE###
#open gnome terminal and run Orb362.jar
gnome-terminal
xdotool sleep 0.5
xdotool type "cd .."
xdotool key Return
TERMID=`xdotool getactivewindow`
DATEVAL=`date +%H:%M_TEST`
xdotool type "java -jar ./Orb362.jar 1 0 0 >> ./test/testOutputs/test1_$DATEVAL.txt"
xdotool key Return

#select orb window
xdotool sleep 0.5
ORBID=`xdotool search --name "Orbit" | sort | head -1`
xdotool windowactivate --sync $ORBID
xdotool sleep 0.5
###TESTING TEMPLATE###


#perform actions in orb
xdotool keydown space
xdotool keyup space
xdotool sleep 0.4
xdotool keydown space
xdotool sleep 3.0
xdotool keyup space
xdotool sleep 1.5

#exit and state saved file
xdotool mousemove --sync -w $ORBID 625 -10
xdotool click 1
xdotool sleep 0.5
xdotool windowclose $TERMID

echo "test1_$DATEVAL"
exit 0
