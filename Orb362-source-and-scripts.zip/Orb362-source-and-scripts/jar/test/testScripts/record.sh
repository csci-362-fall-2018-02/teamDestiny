#!bin/bash

###TESTING TEMPLATE###
#open gnome terminal and run Orb362.jar

gnome-terminal
xdotool sleep 0.5
xdotool type "cd .."
xdotool key Return
TERMID=`xdotool getactivewindow`
#DATEVAL=`date +%H:%M:%S_RECORDING`
xdotool type "java -jar ./Orb362.jar 0 0 1 >> ./test/testScripts/custom/$1.txt"
xdotool key Return

#select orb window
xdotool sleep 0.5
ORBID=`xdotool search --name "Orbit" | sort | head -1`
xdotool windowactivate --sync $ORBID
xdotool sleep 0.5
###TESTING TEMPLATE###

#remain idle while Orb window is still open
TESTID=`xdotool search --name "Orbit" | sort | head -1`
while [ $TESTID -eq $ORBID ]
do
      xdotool sleep 1.0
      TESTID=`xdotool search --name "Orbit" | sort | head -1`
done

#exit and state saved file
xdotool windowclose $TERMID

echo "$1"
exit 0
