#!bin/bash

###TESTING TEMPLATE###
#open gnome terminal and run Orb362.jar

if test "$2" = ""
then
    DEBUGVAL="31"
else
    DEBUGVAL="$2"
fi

gnome-terminal
xdotool sleep 0.5
xdotool type "cd .."
xdotool key Return
TERMID=`xdotool getactivewindow`
DATEVAL=`date +%H:%M_TEST`
CUSTOMFILE="./testScripts/custom/$1.txt"

xdotool type "java -jar ./Orb362.jar $DEBUGVAL 0 $3 >> ./test/testOutputs/$1_$DATEVAL.txt"
xdotool key Return

#select orb window
xdotool sleep 0.5
ORBID=`xdotool search --name "Orbit" | sort | head -1`
xdotool windowactivate --sync $ORBID
xdotool sleep 1.0
###TESTING TEMPLATE###

#perform actions in orb
while IFS= read -r var
do
    xdotool $var  #force commands to window to not interrupt? -w $ORBID 
done < "$CUSTOMFILE"

#exit and state saved file
#xdotool windowactivate --sync $ORBID #uncomment if actions forced with -w
xdotool mousemove --sync -w $ORBID 625 -10
xdotool click 1
xdotool sleep 0.5
xdotool windowclose $TERMID

echo "$1_$DATEVAL"
exit 0
