#!bin/bash

###TESTING TEMPLATE###
#open gnome terminal and run Orb362.jar
gnome-terminal
xdotool sleep 0.5
xdotool type "cd .."
xdotool key Return
TERMID=`xdotool getactivewindow`
DATEVAL=`date +%H:%M_TEST`
xdotool type "java -jar ./Orb362.jar 2 0 0 >> ./test/testOutputs/test2_$DATEVAL.txt"
xdotool key Return

#select orb window
xdotool sleep 0.5
ORBID=`xdotool search --name "Orbit" | sort | head -1`
xdotool windowactivate --sync $ORBID
xdotool sleep 1.0
###TESTING TEMPLATE###


#perform actions in orb
#need to just add more or while some read operation of something
xdotool keydown a
xdotool sleep 0.5
xdotool keyup a
xdotool keydown b
xdotool sleep 0.5
xdotool keyup b
xdotool keydown c
xdotool sleep 0.5
xdotool keyup c
xdotool keydown d
xdotool sleep 0.5
xdotool keyup d
xdotool keydown BackSpace
xdotool sleep 0.5
xdotool keyup BackSpace
xdotool keydown Return
xdotool sleep 0.5
xdotool keyup Return


#exit and state saved file
xdotool mousemove --sync -w $ORBID 625 -10
xdotool click 1
xdotool sleep 0.5
xdotool windowclose $TERMID

echo "test2_$DATEVAL"
exit 0
