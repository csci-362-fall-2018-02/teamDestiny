/*
    This file is part of Orb.

    Orb is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    Orb is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Orb.  If not, see <http://www.gnu.org/licenses/>. 
    
    This software was developed by members of Project:Possibility, a software 
    collaboration for the disabled.
    
    For more information, visit http://projectpossibility.org
*/


/**
 * Collision Detection class
 * Check the player have a collision with an object
 * @author Thuy Truong
 * University of Southern California
 * Code for a Cause 2007
 */

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Polygon;
import java.util.ArrayList;


public class CollisionDetection2 {
    Player player;
    
    //EDIT
    static boolean outside = false;
    static int oldSpeedX;
    static int oldSpeedY;
    static double oldAngle;
    static boolean collision = false;
    //EDIT END
    
    
	//public constructor
	public CollisionDetection2(Player p){
		player = p;
	}
	
	/** 
	 * Boolean function to detect the collision with the wall
	 * @param line
	 * @return true/false
	 */
	public boolean collideWithLine (Line line){
		double a = 0;
		double hypotenuse = 0;
		double distance = 0;
		double incomingAngle = 0;
                
		
		//Calculate the distance of the player to one point on the line
		Line hypo = new Line(line.getEndP(), new DPosition(player.getMainPosition().x.doubleValue(), player.getMainPosition().y.doubleValue()));
		hypotenuse = hypo.length();
		
		//Calculate the length of the line
		a = line.length();
		
		//Distance from the player to the line
		distance = Math.sqrt(Math.pow(hypotenuse,2)- Math.pow(a,2)/4);
		
		if (distance > player.getRadius()) {//make sure we have radius for player
                        collision = false;
			return false;
                }
		else {
                    
                        //EDIT
                        collision = true;
                        //EDIT END
                        
			try {
			//calculate the incoming angle
				incomingAngle = Math.atan(player.getSpeed().x/player.getSpeed().y);
			} catch (ArithmeticException e)
			{
				incomingAngle = Math.PI/2;
			}
			//change the speed of the player according to the new coordinate.
			double newSpeedX = 0;
			double newSpeedY = 0;
                        
                        oldAngle = incomingAngle;
                        oldSpeedX = player.getSpeed().x;
                        oldSpeedY = player.getSpeed().y;
			
			newSpeedX = (double)player.getSpeed().x * Math.cos(incomingAngle)+ (double)player.getSpeed().y * Math.sin(incomingAngle);
			newSpeedY = (double)player.getSpeed().x * (-1) * Math.sin(incomingAngle) + (double)player.getSpeed().y * Math.cos(incomingAngle);
			
			//bouncing speed
			double bouncingSpeedX = 0;
			double bouncingSpeedY = 0;
			
			//when it bounce, only the Y speed change the direction, but the X Speed does not change
			bouncingSpeedX = newSpeedX;
			bouncingSpeedY = (-1)* newSpeedY;
			
			//set the new speed of the ball
			player.setSpeedX((int)Math.round(bouncingSpeedX));
			player.setSpeedY((int)Math.round(bouncingSpeedY));
			
			player.update(true,false);
			player.update(true, false);
			
			
			return true;
		}
	}
	
	/**
	 * Boolean function check when the player have a collision with an object at position with certain size
	 * @param pos
	 * @param size
	 * @return true/false
	 */
	public Boolean genericCollision(Position pos, int size){
		if(Math.abs(player.getMainPosition().x - pos.x) < size/2 + player.getRadius() && Math.abs(player.getMainPosition().y - pos.y) < size/2 + player.getRadius() ){
			return true;
		}
		else{
			return false;
		}
	}
			
        //EDIT
        public void outsideDebug(MapLoader mapLoader, int currentLevel) {
            /*ISSUES WITH COLLISION DETECTION:
            1. IT RELIES ON CALCULATING THE CURRENT DISTANCE FROM ALL LINES, WHERE ANY DISTANCE SHORTER
                    THAN THE RADIUS OF THE PLAYER COUNTS AS A COLLISION.  THIS CAN BE AN ISSUE IF
                    THE VELOCITY OF THE PLAYER CHANGES THE RESULING distance VARIABLE RELATED TO THE LINE
                    IN QUESTION GREATER THAN THE VALUE OF 2*RADIUS OF THE PLAYER IN A SINGLE TICK.
                    WITH THE Polygon CLASS THEY USE TO MAKE THE BOUNDARY WE CAN CHECK IF A GIVEN POINT IS 
                    INSIDE OR NOT WITH THE contains METHOD.
            FIX: SINCE THEY ALREADY INTRODUCED USING THE Polygon CLASS IN ORDER TO DRAW THESE SHAPES WE
                    WE CAN USE THE METHODS WITHIN THE Graphics SUBCLASSES TO DETERMINE COLLISION
            
            2. SPEED X AND SPEED Y EVENTUALLY CONVERTED TO INT FROM DOUBLE?
                    
            */
            
            /*if(collision == true) {
                System.out.printf("Player-Wall Collision: \n"
                        + "Incoming vector: (%d, %d)\n"
                        + "Collision point: (%d, %d)\n"
                        + "Outgoing vector: (%d, %d)\n", oldSpeedX, oldSpeedY,player.getMainPosition().x, player.getMainPosition().y, player.getSpeed().x, player.getSpeed().y);
            }
            collision = false;
            */
            
            Polygon poly = mapLoader.getPolygon(currentLevel);
            Position playerPosition = player.getMainPosition();
            
            //USE Rectangle2D OBJECT AS PLAYER?
            
            if(poly.contains(playerPosition.x, playerPosition.y) == false && outside == false) {
                outside = true;
                System.out.printf("BUG: Player coords out of designated area: %d, %d\n", playerPosition.x, playerPosition.y);
            }
            else if(poly.contains(playerPosition.x, playerPosition.y) == true && outside == true) {
                outside = false;
                System.out.printf("Player coords back inside designated area: %d, %d\n", playerPosition.x, playerPosition.y);
            }
        }
        
        public void starCollideDebug(ArrayList <Star> stars) {
            
            //ISSUE: GOING TO CREATE AN ImageObserver LIST TO GAIN ACCESS TO IMAGE HEIGHT AND WIDTH ATTRIBUTES,
            //THEN MAKE Area OBJECTS WITH THOSE ATTRIBUTES AND TEST WHETHER THE Area OBJECTS CONTAIN A Rectangle2D
            //OBJECT WITH THE CURRENT COORDINATES AND SIZE OF THE PLAYER, BUT HOW THE GameWindow.update() METHOD IS
            //WRITTEN IT CREATES NEW Images EACH UPDATE, SO KEEPING A LIST OF OBSERVERS IN AN EXTERNAL CLASS IS USELESS
            for(int i = 0; i < stars.size(); i++) {
                
            }
        }
        //END EDIT
}